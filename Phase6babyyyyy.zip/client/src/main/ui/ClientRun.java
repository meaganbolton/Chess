package ui;

public class ClientRun {
    public static void main(String[] args) {
        new NotificationHandlers().run();
    }
}
