package webSocketMessages.userCommands;

public class JoinObserver extends UserGameCommand {
    public JoinObserver(){
        super(CommandType.JOIN_OBSERVER);
    }

}
