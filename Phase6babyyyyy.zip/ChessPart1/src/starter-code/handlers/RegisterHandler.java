package handlers;

import com.google.gson.Gson;
import request.RegisterRequest;
import result.LoginResult;
import services.RegisterService;
import spark.*;


public class RegisterHandler extends BaseHandler {
    private final Gson gson = new Gson();

    public Object handle(Request reqData,Response response) {
        RegisterRequest request = gson.fromJson(reqData.body(), RegisterRequest.class);
        RegisterService service = new RegisterService();
        LoginResult result = service.register(request);
        handleResponseErrors(response, result.getMessage());
        return gson.toJson(result);
    }
}