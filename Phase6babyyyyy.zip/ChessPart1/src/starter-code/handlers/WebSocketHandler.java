package handlers;

import chess.*;
import chess.Adapters.ChessMoveAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import models.Game;
import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketMessage;
import org.eclipse.jetty.websocket.api.annotations.WebSocket;
import webSocketMessages.serverMessages.Notification;
import webSocketMessages.serverMessages.Error;
import chess.Adapters.ChessPositionAdapter;
import webSocketMessages.serverMessages.ServerMessage;
import webSocketMessages.userCommands.UserGameCommand;
import dataAccess.GameDAO;
import webSocketMessages.userCommands.JoinPlayer;
import webSocketMessages.userCommands.MakeMove;
import webSocketMessages.websocket.ConnectionManager;
import java.io.IOException;
import java.util.Collection;
import java.util.Objects;


@WebSocket
public class WebSocketHandler {

    private final ConnectionManager connections = new ConnectionManager();

    @OnWebSocketMessage
    public void onMessage(Session session, String message) throws IOException {
        UserGameCommand command = new Gson().fromJson(message, UserGameCommand.class);
        String auth = command.getAuthToken();
        Integer gameID = command.getGameID();
        ChessGame.TeamColor color = null;
        ChessMove move = null;
        if(command.getCommandType() == UserGameCommand.CommandType.JOIN_PLAYER){
            JoinPlayer player = new Gson().fromJson(message, JoinPlayer.class);
            color = player.getPlayerColor();
        }
        if(command.getCommandType() == UserGameCommand.CommandType.MAKE_MOVE){
            command.getGameID();
            Gson gson = new GsonBuilder()
                    .registerTypeAdapter(ChessMove.class, new ChessMoveAdapter())
                    .registerTypeAdapter(ChessPosition.class, new ChessPositionAdapter())
                    .create();
            MakeMove player = gson.fromJson(message, MakeMove.class);
            move = player.getMove();
        }
        try {
            if(AuthDAO.find(auth) == null || GameDAO.find(gameID) == null){
                command = null;
                error(session, "Error: auth or gameID is null");
            }
        } catch (DataAccessException e){
            System.out.println(e.getMessage());
        }
        switch (command.getCommandType()) {
            case JOIN_PLAYER -> joinPlayerH(auth, gameID, color, session);
            case JOIN_OBSERVER -> joinObserverH(auth, gameID, session);
            case MAKE_MOVE -> makeMoveH(move, auth, gameID, session);
            case LEAVE -> leaveH(auth, gameID);
            case RESIGN -> resignH(auth, session, gameID);
            default -> error(session, "Error: Not a valid command");
        }
    }
    private void joinPlayerH(String authtoken,Integer gameID,ChessGame.TeamColor color, Session session) throws IOException {
        String colorr = null;
        if(color == ChessGame.TeamColor.WHITE){
            colorr = "WHITE";
        }if(color == ChessGame.TeamColor.BLACK) {
            colorr = "BLACK";
        }
            try {
                Game game = GameDAO.find(gameID);
                if((game.getWhiteUsername() == null && game.getBlackUsername() == null) ||
                        (Objects.equals(game.getWhiteUsername(), AuthDAO.find(authtoken).getUsername()) && colorr == "BLACK") ||
                        (Objects.equals(game.getBlackUsername(), AuthDAO.find(authtoken).getUsername())&& color == ChessGame.TeamColor.WHITE)){
                    error(session, "Error: joining an empty game");
                }
                else {
                connections.add(gameID, authtoken, AuthDAO.find(authtoken).getUsername(), session);
                ServerMessage messy = new ServerMessage(ServerMessage.ServerMessageType.LOAD_GAME);
                messy.setGame(GameDAO.find(gameID));
                session.getRemote().sendString(new Gson().toJson(messy));
                connections.broadcast(authtoken, gameID, new Notification(AuthDAO.find(authtoken).getUsername() + " has joined the game as " + colorr));
                }
            }catch (DataAccessException e) {
                System.out.print(e.getMessage());
            }
    }
    private void joinObserverH(String authtoken, Integer gameID, Session session) throws IOException {
        Game game = null;
        String username = null;
        try {
            game = GameDAO.find(gameID);
            username = AuthDAO.find(authtoken).getUsername();
        } catch (DataAccessException e) {
            System.out.print(e.getMessage());
        }
        connections.add(gameID, authtoken, username, session);
        try {
            ServerMessage messy = new ServerMessage(ServerMessage.ServerMessageType.LOAD_GAME);
            messy.setGame(GameDAO.find(gameID));
            session.getRemote().sendString(new Gson().toJson(messy));
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
        connections.broadcast(authtoken, gameID,new Notification(username + " joined the game as an observer"));
    }

    private void makeMoveH(ChessMove move, String authtoken, Integer gameID, Session session) throws IOException {
        Boolean found = false;
            try {
                Collection <ChessMove> moves = GameDAO.find(gameID).getGame().validMoves(move.getStartPosition());
                for(ChessMove move1 : moves){
                    if (move1.getEndPosition().getColumn() == move.getEndPosition().getColumn() &&
                            move1.getEndPosition().getRow() == move.getEndPosition().getRow()) {
                        found = true;
                        break;
                    }
                }
                if(GameDAO.find(gameID).getGame().getTeamTurn() == ChessGame.TeamColor.WHITE &&
                        Objects.equals(GameDAO.find(gameID).getBlackUsername(), AuthDAO.find(authtoken).getUsername())){
                    error(session, "Error: playing out of turn");
                }
                else if(GameDAO.find(gameID).getGame().getTeamTurn() == ChessGame.TeamColor.BLACK &&
                        Objects.equals(GameDAO.find(gameID).getWhiteUsername(), AuthDAO.find(authtoken).getUsername())){
                    error(session, "Error: playing out of turn");
                }
                else if(!found){
                    error(session, "Error: Not a valid move");
                }
                else if(Objects.isNull(connections.find(GameDAO.find(gameID).getWhiteUsername(), gameID)) ||
                        Objects.isNull(connections.find(GameDAO.find(gameID).getBlackUsername(), gameID))) {
                    error(session, "Error: you need to wait for another player to join");
                }
                else if(!Objects.equals(Objects.requireNonNull(GameDAO.find(gameID)).getBlackUsername(), Objects.requireNonNull(AuthDAO.find(authtoken)).getUsername()) &&
                        !Objects.equals(GameDAO.find(gameID).getWhiteUsername(), AuthDAO.find(authtoken).getUsername())){
                    error(session, "Error: Only players can make a move (you are not a player)");
                }
                else {
                    String username = AuthDAO.find(authtoken).getUsername();
                    String start = "(" + move.getStartPosition().getRow() + ", " + move.getStartPosition().getColumn() + ")";
                    String end = "(" + move.getEndPosition().getRow() + ", " + move.getEndPosition().getColumn() + ")";
                    String piece = GameDAO.find(gameID).getGame().getBoard().getPiece(move.getStartPosition()).getPieceType().toString();
                    ChessGame game = GameDAO.find(gameID).getGame();
                    game.makeMove(move);
                    GameDAO.upDate(gameID, game);
                    ServerMessage messy = new ServerMessage(ServerMessage.ServerMessageType.LOAD_GAME);
                    messy.setGame(GameDAO.find(gameID));
                    if(GameDAO.find(gameID).getGame().isInCheck(ChessGame.TeamColor.WHITE)){
                        connections.broadcast(authtoken, gameID, messy);
                        connections.broadcast(authtoken, gameID, new Notification(username + " moved " + piece + " from " + start + " to " + end + "white is in check"));
                    }
                    else if(GameDAO.find(gameID).getGame().isInCheck(ChessGame.TeamColor.BLACK)){
                        connections.broadcast(authtoken, gameID, messy);
                        connections.broadcast(authtoken, gameID, new Notification(username + " moved " + piece + " from " + start + " to " + end + "black is in check"));
                    }
                    else if(GameDAO.find(gameID).getGame().isInCheckmate(ChessGame.TeamColor.WHITE)){
                        connections.broadcast(authtoken, gameID, messy);
                        connections.broadcast(authtoken, gameID, new Notification(username + " moved " + piece + " from " + start + " to " + end + "white is in checkmate"));
                    }
                    else if(GameDAO.find(gameID).getGame().isInCheckmate(ChessGame.TeamColor.BLACK)){
                        connections.broadcast(authtoken, gameID, messy);
                        connections.broadcast(authtoken, gameID, new Notification(username + " moved " + piece + " from " + start + " to " + end + "black is in checkmate"));
                    }else {
                        session.getRemote().sendString(new Gson().toJson(messy));
                        connections.broadcast(authtoken, gameID, messy);
                        connections.broadcast(authtoken, gameID, new Notification(username + " moved " + piece + " from " + start + " to " + end));
                    }
                }
            } catch (DataAccessException e) {
                error(session, "Error: This is a data Access Exception error");
            } catch (InvalidMoveException e) {
                error(session, "Error: This is an invalid move exception error");
            }
    }
    private void leaveH(String authtoken, Integer gameID) {
        try {
            connections.broadcast(authtoken, gameID, new Notification(AuthDAO.find(authtoken).getUsername() + " has left the game"));
            connections.remove(authtoken, gameID);
        } catch (Exception e) {
            System.out.print(e.getMessage());
        }
    }

    private void resignH(String authtoken,Session session, Integer gameID) {
        try {
            if(!Objects.equals(Objects.requireNonNull(GameDAO.find(gameID)).getBlackUsername(), AuthDAO.find(authtoken).getUsername()) &&
                    !Objects.equals(Objects.requireNonNull(GameDAO.find(gameID)).getWhiteUsername(), AuthDAO.find(authtoken).getUsername())){
                error(session, "Error: Can't resign if you're not one of the players");
            }
            else if(Objects.isNull(connections.find(Objects.requireNonNull(GameDAO.find(gameID)).getWhiteUsername(), gameID)) ||
                    Objects.isNull(connections.find(Objects.requireNonNull(GameDAO.find(gameID)).getBlackUsername(), gameID))) {
                error(session, "Error: Can't resign if you're not connected to the game?");
            }
            else{
                Notification notif = new Notification(Objects.requireNonNull(AuthDAO.find(authtoken)).getUsername() + " has resigned");
                session.getRemote().sendString(new Gson().toJson(notif));
                connections.remove(authtoken, gameID);
                connections.broadcast(authtoken, gameID, notif);
            }
        } catch (Exception e) {
            System.out.print(e.getMessage());
        }
    }

    public void error(Session session, String sound) throws IOException {
            session.getRemote().sendString(new Gson().toJson(new Error(sound)));
    }
}