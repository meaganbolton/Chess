package handlers;

import com.google.gson.Gson;
import result.BaseResult;
import services.LogoutService;
import spark.*;

public class LogoutHandler extends BaseHandler {
    private final Gson gson = new Gson();

    public Object handle(Request reqData, Response response){
        LogoutService service = new LogoutService();
        BaseResult result = service.logout(reqData.headers("Authorization"));
        handleResponseErrors(response, result.getMessage());

        return gson.toJson(result);
    }

}