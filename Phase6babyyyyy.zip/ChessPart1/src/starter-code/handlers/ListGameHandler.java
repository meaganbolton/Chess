package handlers;

import com.google.gson.Gson;
import result.ListGameResult;
import services.ListGameService;
import spark.Request;
import spark.Response;

public class ListGameHandler extends BaseHandler {
    private final Gson gson = new Gson();

    public Object handle(Request reqData, Response response) {
        String authToken = reqData.headers("Authorization");

        ListGameService service = new ListGameService();
        ListGameResult result = service.list(authToken);
        handleResponseErrors(response, result.getMessage());
        return gson.toJson(result);
    }

}