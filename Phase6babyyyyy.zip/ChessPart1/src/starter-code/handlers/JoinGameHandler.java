package handlers;

import com.google.gson.Gson;
import request.JoinGameRequest;
import result.BaseResult;
import services.JoinGameService;
import spark.Request;
import spark.Response;

public class JoinGameHandler extends BaseHandler {
    private final Gson gson = new Gson();

    public Object handle(Request reqData, Response response) {
        String authToken = reqData.headers("Authorization");

        JoinGameRequest request = gson.fromJson(reqData.body(), JoinGameRequest.class);
        BaseResult result = new JoinGameService().joinGame(request, authToken);
        handleResponseErrors(response, result.getMessage());
        return gson.toJson(result);
    }

}