package handlers;

import spark.Request;
import spark.Response;
import spark.Route;

public class BaseHandler implements Route {
    protected void handleResponseErrors(Response response, String message) {
        if (message == null) {
            response.status(200);
        } else if (message.equals("Error: bad request")) {
            response.status(400);
        } else if (message.equals("Error: unauthorized")) {
            response.status(401);
        } else if (message.equals("Error: already taken")) {
            response.status(403);
        } else if (message.equals("Error: description")) {
            response.status(500);
        }
    }

    @Override
    public Object handle(Request request, Response response) throws Exception {
        return null;
    }

}