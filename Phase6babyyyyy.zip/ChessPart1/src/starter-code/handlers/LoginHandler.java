package handlers;

import com.google.gson.Gson;
import request.LoginRequest;
import result.LoginResult;
import services.LoginService;
import spark.Request;
import spark.Response;


public class LoginHandler extends BaseHandler {
    private final Gson gson = new Gson();

    public Object handle(Request reqData, Response response)  {
        LoginRequest request = gson.fromJson(reqData.body(), LoginRequest.class);

        LoginService service = new LoginService();
        LoginResult result = service.login(request);
        handleResponseErrors(response, result.getMessage());
        return gson.toJson(result);
    }

}