package handlers;

import com.google.gson.Gson;
import request.CreateGameRequest;
import result.CreateGameResult;
import services.CreateGameService;
import spark.Request;
import spark.Response;

public class CreateGameHandler extends BaseHandler {
    private final Gson gson = new Gson();

    public Object handle(Request reqData, Response response) {
        CreateGameRequest request = gson.fromJson(reqData.body(), CreateGameRequest.class);
        String authToken = reqData.headers("Authorization");
        CreateGameResult result = new CreateGameService().createGame(request, authToken);
        handleResponseErrors(response, result.getMessage());
            return gson.toJson(result);
        }

}