package handlers;

import com.google.gson.Gson;
import dataAccess.DataAccessException;
import result.BaseResult;
import services.ClearService;
import spark.*;

public class ClearHandler extends BaseHandler {
    private final Gson gson = new Gson();
    @Override
    public Object handle(Request reqData,Response response) throws DataAccessException {
            ClearService service = new ClearService();
            BaseResult result = service.clear();
            return gson.toJson(result);
    }

}