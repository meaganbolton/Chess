package dataAccess;

import models.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static dataAccess.Database.getConnection;

/**
 * The UserDAO class provides data access operations for user data.
 */
public class UserDAO {


    public static void insert(User user) throws DataAccessException {
        Connection con = getConnection();
        try(PreparedStatement prep = con.prepareStatement("INSERT INTO users SET username = ?, password = ?, email = ?")){
            prep.setString(1, user.getUsername());
            prep.setString(2, user.getPassword());
            prep.setString(3, user.getEmail());

            prep.executeUpdate();
            con.close();
        }catch(SQLException e){
            throw new DataAccessException("Error: " + e.getMessage());
        }
    }

    public static void clear() {
        try {
            Connection con = getConnection();
            try (PreparedStatement prep = con.prepareStatement("DELETE FROM users")) {
                prep.executeUpdate();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            } finally {
                try {
                    con.close();
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
            }
        } catch(DataAccessException e) {
            System.out.println(e.getMessage());
        }
    }
    public static User find(String username) throws DataAccessException{
        if(username == null) {
            throw new DataAccessException("Error: unauthorized");
        }
        Connection con = getConnection();
        try (PreparedStatement prep = con.prepareStatement("SELECT * FROM users WHERE username = ?")) {
            prep.setString(1, username);
            ResultSet res = prep.executeQuery();
            String password;
            String email;
            if(res.next()) {
                password = res.getString("password");
                email = res.getString("email");
            } else return null;
            con.close();
            return new User(username, password, email);
        } catch (SQLException e) {
            throw new DataAccessException("Error: " + e.getMessage());
        }
    }
}
