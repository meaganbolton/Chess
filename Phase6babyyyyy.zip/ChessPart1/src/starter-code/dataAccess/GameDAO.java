package dataAccess;

import chess.*;
import models.Game;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import static dataAccess.Database.getConnection;

/**
 * The GameDAO class provides data access operations for game-related data.
 */
public class GameDAO {
    public static void insert(Game game) throws DataAccessException {
        Connection con = getConnection();
        try(PreparedStatement prep = con.prepareStatement("INSERT INTO games SET gameID = ?, whiteUsername = ?, blackUsername = ?, gameName = ?, game = ?")){
            String strID = Integer.toString(game.getGameID());
            prep.setString(1, strID);
            prep.setString(2, game.getWhiteUsername());
            prep.setString(3, game.getBlackUsername());
            prep.setString(4, game.getGameName());
            prep.setString(5, ChessGames.serialization().toJson(game.getGame()));
            prep.executeUpdate();
            con.close();
        }catch(SQLException e){
            throw new DataAccessException("Error: " + e.getMessage());
        }
    }
    public static void upDate(int gameID, ChessGame game) throws DataAccessException {
        Connection con = getConnection();
        try(PreparedStatement prep = con.prepareStatement("UPDATE games SET game = ? WHERE gameID = ?")){
            String strID = Integer.toString(gameID);
            prep.setString(1, ChessGames.serialization().toJson(game));
            prep.setString(2, strID);
            prep.executeUpdate();
            con.close();
        }catch(SQLException e){
            throw new DataAccessException("Error: " + e.getMessage());
        }
    }

    public static Game find(Integer gameID) throws DataAccessException{
        if(gameID == null) {
            throw new DataAccessException("Error: unauthorized");
        }
        Connection con = getConnection();
        try (PreparedStatement prep = con.prepareStatement("SELECT * FROM games WHERE gameID = ?")) {
            String strID = Integer.toString(gameID);
            prep.setString(1, strID);
            ResultSet res = prep.executeQuery();
            String whiteUsername;
            String blackUsername;
            String gameName;
            String games1;
            if(res.next()) {
                whiteUsername = res.getString("whiteUsername");
                blackUsername = res.getString("blackUsername");
                gameName = res.getString("gameName");
                games1 = res.getString("game");
            } else {
                return null;}
            con.close();
            Game game = new Game(gameID, gameName);
            game.setWhiteUsername(whiteUsername);
            game.setBlackUsername(blackUsername);
            ChessGame game3 = ChessGames.serialization().fromJson(games1, ChessGame.class);
            game.setGame(game3);
            return game;
        } catch (SQLException e) {
            throw new DataAccessException("Error: " + e.getMessage());
        }
    }

    public static ArrayList<Game> findAll() {
        ArrayList<Game> gamesList = new ArrayList<>();
        try {
            Connection con = getConnection();
        try (PreparedStatement prep = con.prepareStatement("SELECT * FROM games")) {
            try (ResultSet result = prep.executeQuery()) {
                while (result.next()) {
                    gamesList.add(find(result.getInt("gameID")));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace(); // Handle the exception appropriately
            }
        }
        } catch(DataAccessException e) {
            System.out.println(e.getMessage());
        }
        return gamesList;
    }

    public static void claimSpot(int gameID, String color, String username) throws DataAccessException {

        if (Objects.equals(color, "WHITE")) {
            if(GameDAO.find(gameID).getWhiteUsername() != null) {
                System.out.print("the error is bc there is already a person in the white position");
                throw new DataAccessException("Error: already taken");
            }
            Connection con = getConnection();
            try (PreparedStatement updateStmt = con.prepareStatement("UPDATE games SET whiteUsername = ? WHERE gameID = ?")) {
                updateStmt.setString(1, username);
                updateStmt.setString(2, Integer.toString(gameID));
                updateStmt.executeUpdate();
                con.close();
            } catch (SQLException e) {
                throw new DataAccessException("Error: bad request");
            }
        }
        else if (Objects.equals(color, "BLACK")) {
            if(GameDAO.find(gameID).getBlackUsername() != null) {
                System.out.print("There is already a user in black position");
                throw new DataAccessException("Error: already taken");
            }
            Connection con = getConnection();
            try (PreparedStatement updateStmt = con.prepareStatement("UPDATE games SET blackUsername = ? WHERE gameID = ?")) {
                updateStmt.setString(1, username);
                updateStmt.setString(2, Integer.toString(gameID));
                updateStmt.executeUpdate();
                con.close();
            } catch (SQLException e) {
                throw new DataAccessException("Error: bad request");
            }
        } else{
            throw new DataAccessException("Error: description");
        }
    }

    public static void clear(){
        try {
            Connection con = getConnection();
            try (PreparedStatement prep = con.prepareStatement("DELETE FROM games")) {
                prep.executeUpdate();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            } finally {
                try {
                    con.close();
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
            }
        } catch(DataAccessException e) {
            System.out.println(e.getMessage());
        }
    }
}
