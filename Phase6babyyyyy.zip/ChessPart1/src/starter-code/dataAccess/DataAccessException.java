package dataAccess;

/**
 * Indicates there was an error connecting to the database
 */
public class DataAccessException extends Exception{
    /**
     * Constructs a new DataAccessException object with specified message.
     * @param message the message
     */
    public DataAccessException(String message) {
        super(message);
    }
}
