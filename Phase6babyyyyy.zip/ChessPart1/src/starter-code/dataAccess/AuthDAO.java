package dataAccess;

import models.Authtoken;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * The AuthDAO class provides data access operations for authentication tokens.
 */
public class AuthDAO extends Database {

    public static void insert(Authtoken authtoken) throws DataAccessException {
        Connection con = getConnection();
        try(PreparedStatement prep = con.prepareStatement("INSERT INTO authTokens SET authToken = ?, username = ?")){
            prep.setString(1, authtoken.getAuthoToken());
            prep.setString(2, authtoken.getUsername());
            prep.executeUpdate();
            con.close();
        }catch(SQLException e){
            throw new DataAccessException("Error: " + e.getMessage());
        }
    }

    public static void delete(String authtokenID) throws DataAccessException {
        if(authtokenID == null) {
            throw new DataAccessException("Error: unauthorized");
        }
        Connection con = getConnection();
        try(PreparedStatement prep = con.prepareStatement("DELETE FROM authTokens WHERE authToken = ?")){
            prep.setString(1, authtokenID);
            prep.executeUpdate();
            con.close();
        }catch(SQLException e){
            throw new DataAccessException("Error: " + e.getMessage());
        }
    }

    public static void clear() {
        try {
            Connection con = getConnection();
            try (PreparedStatement prep = con.prepareStatement("DELETE FROM authTokens")) {
                prep.executeUpdate();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            } finally {
                try {
                    con.close();
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
            }
        } catch(DataAccessException e) {
            System.out.println(e.getMessage());
        }

    }

    public static Authtoken find(String authtokenID) throws DataAccessException {
        if(authtokenID == null) {
            throw new DataAccessException("Error: unauthorized");
        }
        Connection con = getConnection();
        try (PreparedStatement prep = con.prepareStatement("SELECT * FROM authTokens WHERE authToken = ?")) {
            prep.setString(1, authtokenID);

            ResultSet res = prep.executeQuery();
            String username;
            String authtoken;
            if(res.next()) {
                authtoken = res.getString("authToken");
                username = res.getString("username");
            } else {
                return null;
            }
            con.close();
            return new Authtoken(authtoken, username);

        } catch (SQLException e) {
            throw new DataAccessException("Error: " + e.getMessage());
        }
    }

}
