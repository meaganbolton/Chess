package services;

import dataAccess.AuthDAO;
import dataAccess.GameDAO;
import dataAccess.UserDAO;
import result.BaseResult;

/**
 * The ClearService class provides the service to clear the server's data.
 */
public class ClearService {

    /**
     * Constructs a new ClearService.
     */
    public ClearService(){
    }
    /**
     * Clears all data from the server.
     *
     * @return A FailureResult indicating the failure of the clear operation.
     */
    public BaseResult clear() {
        new AuthDAO().clear();
        new GameDAO().clear();
        new UserDAO().clear();
        return new BaseResult();
    }
}

