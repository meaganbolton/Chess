package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import dataAccess.GameDAO;
import result.ListGameResult;

/**
 * The ListGameService class provides the service to retrieve a list of games.
 */
public class ListGameService {
    /**
     * Constructs a new ListGameService.
     */
    public ListGameService(){}

    /**
     * Retrieves a list of games.
     *
     * @return A ListGameResult containing the list of games.
     */
    public ListGameResult list(String authtoken) {
        ListGameResult results = new ListGameResult();
        try{
            if(AuthDAO.find(authtoken) == null) {
                throw new DataAccessException("Error: unauthorized");
            }
            results.setGames(GameDAO.findAll());
        }catch (DataAccessException e){
            results.setMessage(e.getMessage());
        }
        return results;
    }
}
