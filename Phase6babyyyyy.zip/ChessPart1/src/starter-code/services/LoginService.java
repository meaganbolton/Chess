package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import dataAccess.UserDAO;
import models.Authtoken;
import models.User;
import request.LoginRequest;
import result.LoginResult;

import java.util.UUID;

/**
 * The LoginService class provides the service to log in an existing user based on a LoginRequest.
 */
public class LoginService {
    /**
     * Constructs a new LoginService.
     */
    public LoginService(){}
    /**
     * Logs in an existing user based on the provided request.
     *
     * @param request The LoginRequest containing user login information.
     * @return A LoginResult with the result of the login operation.
     */
    public LoginResult login(LoginRequest request) {
        LoginResult results = new LoginResult();
        try{
            if(UserDAO.find(request.getUsername()) != null) {
                User user = UserDAO.find(request.getUsername());
                if(user.getPassword().equals(request.getPassword())) {
                    results.setUsername(user.getUsername());
                    Authtoken authtoken = new Authtoken(UUID.randomUUID().toString(), request.getUsername());
                    results.setAuthToken(authtoken.getAuthoToken());
                    AuthDAO.insert(authtoken);
                } else throw new DataAccessException("Error: unauthorized");
            } else throw new DataAccessException("Error: unauthorized");
        }catch (DataAccessException e){
            results.setMessage(e.getMessage());
        }
        return results;
    }
}
