package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import result.BaseResult;

/**
 * The LogoutService class provides the service to log out a user.
 */
public class LogoutService {
    /**
     * Constructs a new LogoutService.
     */
    public LogoutService(){}
    /**
     * Logs out the user.
     *
     * @param token An authtoken containing the authentication token.
     * @return A FailureResult indicating the failure of the logout operation.
     */
    public BaseResult logout(String token) {
        BaseResult results = new BaseResult();
        try{
            if(AuthDAO.find(token) != null) {
                AuthDAO.delete(token);
            }else throw new DataAccessException("Error: unauthorized");
        }catch (DataAccessException e){
            results.setMessage("Error: unauthorized");
        }
        return results;
    }
}
