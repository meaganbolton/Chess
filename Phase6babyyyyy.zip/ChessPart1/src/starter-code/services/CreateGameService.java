package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import models.Game;
import request.CreateGameRequest;
import result.CreateGameResult;
import dataAccess.GameDAO;
import java.util.UUID;

/**
 * The CreateGameService class provides the service to create a new game based on a CreateGameRequest.
 */
public class CreateGameService {
    /**
     * Constructs a new CreateGameService.
     */
    public CreateGameService(){}

    /**
     * Creates a new game based on the provided request.
     *
     * @param request The CreateGameRequest containing the game name.
     * @return A CreateGameResult with the result of the create game operation.
     */
    public CreateGameResult createGame(CreateGameRequest request, String authtoken) {
        CreateGameResult results = new CreateGameResult();
        try{
            if(request.getGameName() == null){
                throw new DataAccessException("Error: bad request");
            }
            if(AuthDAO.find(authtoken) == null) {
                throw new DataAccessException("Error: unauthorized");
            }
            int theID = UUID.randomUUID().hashCode();
            if(theID < 0){
                theID = theID * -1;
            }
            results.setGameID(theID);
            results.setGameName(request.getGameName());
            GameDAO.insert(new Game(results.getGameID(), request.getGameName()));
        }catch (DataAccessException e){
            results.setMessage(e.getMessage());
        }
        return results;
    }
}
