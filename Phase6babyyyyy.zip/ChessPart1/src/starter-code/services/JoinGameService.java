package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import dataAccess.GameDAO;
import request.JoinGameRequest;
import result.BaseResult;

/**
 * The JoinGameService class provides the service to join an existing game based on a JoinGameRequest.
 */
public class JoinGameService {
    /**
     * Constructs a new JoinGameService.
     */
    public JoinGameService(){}
    /**
     * Joins an existing game based on the provided request.
     *
     * @param request The JoinGameRequest containing game and player information.
     * @return FailureResult containing a faliure message.
     */
    public BaseResult joinGame(JoinGameRequest request, String authtoken) {
        BaseResult results = new BaseResult();
        try{
            if(GameDAO.find(request.getGameID()) == null){
                throw new DataAccessException("Error: bad request");
            }
            if(AuthDAO.find(authtoken) == null) {
                throw new DataAccessException("Error: unauthorized");
            }
            if(request.getPlayerColor() != null) {
                GameDAO.claimSpot(request.getGameID(), request.getPlayerColor(), AuthDAO.find(authtoken).getUsername());
            }
        }catch (DataAccessException e){
            results.setMessage(e.getMessage());
        }
        return results;
    }
}
