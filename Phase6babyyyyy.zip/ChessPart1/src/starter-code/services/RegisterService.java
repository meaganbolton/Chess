package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import models.Authtoken;
import models.User;
import request.RegisterRequest;
import result.LoginResult;
import dataAccess.UserDAO;
import java.util.UUID;

/**
 * The RegisterService class provides the service to register a new user based on a RegisterRequest.
 */
public class RegisterService {
    /**
     * Constructs a new RegisterService.
     */
    public RegisterService(){}
    /**
     * Registers a new user based on the provided request.
     *
     * @param request The RegisterRequest containing user registration information.
     * @return A LoginResult with the result of the registration operation.
     */
    public LoginResult register(RegisterRequest request) {
        LoginResult results = new LoginResult();
        try{
            if(request.getUsername() == null || request.getPassword() == null || request.getEmail() == null){
                throw new DataAccessException("Error: bad request");
            }
            User user = new User(request.getUsername(), request.getPassword(), request.getEmail());
            if(UserDAO.find(user.getUsername()) != null) {
                throw new DataAccessException("Error: already taken");
            }
            UserDAO.insert(user);
            results.setUsername(request.getUsername());
            results.setAuthToken(UUID.randomUUID().toString());
            AuthDAO.insert(new Authtoken(results.getAuthToken(), results.getUsername()));
        }catch (DataAccessException e){
            results.setMessage(e.getMessage());
        }
        return results;
    }
}
