package server;

import handlers.*;
import org.eclipse.jetty.websocket.api.annotations.*;
import spark.Spark;
import handlers.WebSocketHandler;

@WebSocket
public class Server {

    public static void main(String[] args) {
        new Server().run();
    }
    private void run(){
        Spark.port(8080);
        Spark.webSocket("/connect", WebSocketHandler.class);
        Spark.externalStaticFileLocation("web");
        Spark.delete("/db", new ClearHandler());
        Spark.post("/user", new RegisterHandler());
        Spark.post("/session", new LoginHandler());
        Spark.delete("/session", new LogoutHandler());
        Spark.get("/game", new ListGameHandler());
        Spark.post("/game", new CreateGameHandler());
        Spark.put("/game", new JoinGameHandler());
        Spark.get("/echo/:msg", (req, res) -> "HTTP response: " + req.params(":msg"));
    }

}