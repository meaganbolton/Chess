package passoffTests.DAOTests;
import dataAccess.*;
import models.Authtoken;
import models.Game;
import models.User;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class DAOTestiTests {
    @Test
    @DisplayName("Valid test AuthDAO Insert")
    public void successAuthInsert(){
        AuthDAO.clear();

        Assertions.assertDoesNotThrow(new Executable() {
            @Override
            public void execute() throws Throwable {
                AuthDAO.insert(new Authtoken("1234", "Meagatron"));
            }
        }, "auth insert find didn't work");

    }
    @Test
    @DisplayName("Invalid test AuthDAO Insert")
    public void failureAuthInsert(){
        Assertions.assertThrows(DataAccessException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                AuthDAO.insert(new Authtoken(null, "Meagatron"));
            }
        }, "The message doesn't return \"bad request\"");

        Assertions.assertThrows(DataAccessException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                AuthDAO.insert(new Authtoken("1234", "Meagatron"));
                AuthDAO.insert(new Authtoken("1234", "Meagatron"));
            }
        }, "The message doesn't return \"bad request\"");

    }

    @Test
    @DisplayName("Valid test AuthDAO Delete")
    public void successAuthDelete(){
        AuthDAO.clear();

        Assertions.assertDoesNotThrow(new Executable() {
            @Override
            public void execute() throws Throwable {
                AuthDAO.insert(new Authtoken("1234", "Meagatron"));
                AuthDAO.insert(new Authtoken("567", "NotYourMom"));
                AuthDAO.insert(new Authtoken("8910", "Bruh"));
                AuthDAO.delete("567");
            }
        }, "auth delete didn't work");
    }

    @Test
    @DisplayName("Invalid test AuthDAO Delete")
    public void failureAuthDelete(){
        AuthDAO.clear();

        Assertions.assertThrows(DataAccessException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                AuthDAO.insert(new Authtoken("1234", "Meagatron"));
                AuthDAO.insert(new Authtoken("567", "NotYourMom"));
                AuthDAO.insert(new Authtoken("8910", "Bruh"));
                AuthDAO.delete(null);
            }
        }, "The message doesn't return the right error");
    }
    @Test
    @DisplayName("Valid test AuthDAO Find")
    public void successAuthFind() {

        AuthDAO.clear();
        final Authtoken[] authtoken = {null};

        Assertions.assertDoesNotThrow(new Executable() {
            @Override
            public void execute() throws Throwable {
                AuthDAO.insert(new Authtoken("1234", "Meagatron"));
                AuthDAO.insert(new Authtoken("567", "NotYourMom"));
                AuthDAO.insert(new Authtoken("8910", "Bruh"));
                authtoken[0] = AuthDAO.find("567");
            }
        }, "auth find didn't work");

        Assertions.assertEquals("NotYourMom", authtoken[0].getUsername(), "The usernames don't match");
    }
    @Test
    @DisplayName("Invalid test AuthDAO Find")
    public void failureAuthFind() {
        AuthDAO.clear();

        Assertions.assertThrows(DataAccessException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                AuthDAO.insert(new Authtoken("1234", "Meagatron"));
                AuthDAO.insert(new Authtoken("567", "NotYourMom"));
                AuthDAO.insert(new Authtoken("8910", "Bruh"));
                AuthDAO.find(null);
            }
        }, "The message doesn't return the right error");
    }
    @Test
    @DisplayName("Valid test AuthDAO clear")
    public void successAuthClear(){
        AuthDAO.clear();
        Assertions.assertDoesNotThrow(() -> {
            AuthDAO.insert(new Authtoken("1234", "Meagatron"));
            AuthDAO.insert(new Authtoken("567", "NotYourMom"));
            AuthDAO.insert(new Authtoken("8910", "Bruh"));
        }, "clear didn't work");
        AuthDAO.clear();
        Assertions.assertDoesNotThrow(() -> {
            AuthDAO.insert(new Authtoken("1234", "Meagatron"));
            AuthDAO.insert(new Authtoken("567", "NotYourMom"));
            AuthDAO.insert(new Authtoken("8910", "Bruh"));
        }, "clear didn't work");
    }

   @Test
    @DisplayName("Valid test userDAO Insert")
    public void successInsertUser(){
        UserDAO.clear();
       Assertions.assertDoesNotThrow(() -> {
           UserDAO.insert(new User("meagatron", "pass", "megs@gmail"));
       }, "insert didn't work");
    }
    @Test
    @DisplayName("Invalid test userDAO Insert")
    public void faliureInsertUser(){

        Assertions.assertThrows(DataAccessException.class, () -> {
            UserDAO.insert(new User(null, "pass", "megs@gmail"));
        }, "insert didn't return the right error");

    }
    @Test
    @DisplayName("Valid test userDAO Find")
    public void successFindUser(){
        UserDAO.clear();

        Assertions.assertDoesNotThrow(() -> {
            User user = null;
            UserDAO.insert(new User("meagatron", "pass", "megs@gmail"));
            UserDAO.insert(new User("rains", "pass2", "rains@gmail"));
            UserDAO.insert(new User("bolton", "pass3", "bolton@gmail"));
            user =UserDAO.find("rains");
            Assertions.assertEquals("rains@gmail", user.getEmail(), "The usernames don't match");

        }, "find didn't work");

    }
    @Test
    @DisplayName("Invalid test userDAO Find")
    public void failurefindUser(){
        UserDAO.clear();

        Assertions.assertThrows(DataAccessException.class, () -> {
            UserDAO.insert(new User("meagatron", "pass", "megs@gmail"));
            UserDAO.insert(new User("rains", "pass2", "rains@gmail"));
            UserDAO.insert(new User("bolton", "pass3", "bolton@gmail"));
            UserDAO.find(null);
        }, "find fail didn't return right message");
    }
    @Test
    @DisplayName("Valid test userDAO clear")
    public void successUserClear(){
        UserDAO.clear();

        Assertions.assertDoesNotThrow(() -> {
            UserDAO.insert(new User("meagatron", "pass", "megs@gmail"));
            UserDAO.insert(new User("rains", "pass2", "rains@gmail"));
            UserDAO.insert(new User("bolton", "pass3", "bolton@gmail"));
        }, "clear didn't work");

        UserDAO.clear();

        Assertions.assertDoesNotThrow(() -> {
            UserDAO.insert(new User("meagatron", "pass", "megs@gmail"));
            UserDAO.insert(new User("rains", "pass2", "rains@gmail"));
            UserDAO.insert(new User("bolton", "pass3", "bolton@gmail"));
        }, "clear didn't work");
    }
    @Test
    @DisplayName("Valid test gameDAO Insert")
    public void successGameInsert(){
        GameDAO.clear();

        Assertions.assertDoesNotThrow(() -> {
            GameDAO.insert(new Game(1002, "Game1"));
        }, "game insert didn't work");
    }
    @Test
    @DisplayName("Invalid test gameDAO Insert")
    public void failureGameInsert(){
        GameDAO.clear();
        Assertions.assertDoesNotThrow(() -> {
            GameDAO.insert(new Game(1002, "Game1"));
        }, "game insert didn't work");
    }
    @Test
    @DisplayName("Valid test gameDAO Find")
    public void successGameFind(){
        GameDAO.clear();

        Assertions.assertDoesNotThrow(() -> {
            Game game = null;

            GameDAO.insert(new Game(1002, "Game1"));
            GameDAO.insert(new Game(345, "Game2"));
            GameDAO.insert(new Game(987, "Game3"));
            game = GameDAO.find(345);
            Assertions.assertEquals("Game2", game.getGameName(), "The game names don't match");

        }, "game find didn't work");
    }
    @Test
    @DisplayName("Invalid test gameDAO Find")
    public void failureGameFind(){
        GameDAO.clear();

        Assertions.assertThrows(DataAccessException.class, () -> {
            GameDAO.insert(new Game(1002, "Game1"));
            GameDAO.insert(new Game(345, "Game2"));
            GameDAO.insert(new Game(987, "Game3"));
            GameDAO.find(null);
        }, "game error isn't correct");

    }
    @Test
    @DisplayName("Valid test GameDAO FindAll")
    public void successGamefindAll(){
        GameDAO.clear();

        Assertions.assertDoesNotThrow(() -> {
            ArrayList<Game> gameList = new ArrayList<>();

            GameDAO.insert(new Game(1002, "Game1"));
            GameDAO.insert(new Game(345, "Game2"));
            GameDAO.insert(new Game(987, "Game3"));
            gameList = GameDAO.findAll();
            Assertions.assertEquals(1002, gameList.get(0).getGameID(), "Incorrect ID shown");
            Assertions.assertEquals("Game1", gameList.get(0).getGameName(), "Incorrect game name shown");
            Assertions.assertEquals(345, gameList.get(1).getGameID(), "Incorrect ID shown game2");
            Assertions.assertEquals("Game2", gameList.get(1).getGameName(), "Incorrect game name shown game2");
        }, "game find didn't work");

    }
    @Test
    @DisplayName("Invalid test GameDAO FindAll")
    public void failureGamefindAll(){
        GameDAO.clear();

        Assertions.assertDoesNotThrow(() -> {
            GameDAO.insert(new Game(1002, "Game1"));
            GameDAO.findAll();
        }, "there is actually no way for this to fail");

    }


    @Test
    @DisplayName("Valid test gameDAO ClaimSpot")
    public void successGameClaimSpot(){
        GameDAO.clear();

        Assertions.assertDoesNotThrow(() -> {
            GameDAO.insert(new Game(1002, "Game1"));
            GameDAO.insert(new Game(345, "Game2"));
            GameDAO.insert(new Game(987, "Game3"));
            GameDAO.claimSpot(1002, "WHITE", "meagatron");
        }, "game claimspot find didn't work");

    }
    @Test
    @DisplayName("Invalid test gameDAO ClaimSpot")
    public void failedGameClaimSpot(){
        GameDAO.clear();

        Assertions.assertThrows(DataAccessException.class, () -> {
            GameDAO.insert(new Game(1002, "Game1"));
            GameDAO.insert(new Game(345, "Game2"));
            GameDAO.insert(new Game(987, "Game3"));
            GameDAO.claimSpot(1002, null, "meagatron");
        }, "game claimspot didn't return the right message");

    }
    @Test
    @DisplayName("Valid test gameDAO clear")
    public void successGameClear(){
        GameDAO.clear();

        Assertions.assertDoesNotThrow(() -> {
            GameDAO.insert(new Game(1002, "Game1"));
            GameDAO.insert(new Game(345, "Game2"));
            GameDAO.insert(new Game(987, "Game3"));
        }, "there is actually no way for this to fail");

        GameDAO.clear();

        Assertions.assertDoesNotThrow(() -> {
            GameDAO.insert(new Game(1002, "Game1"));
            GameDAO.insert(new Game(345, "Game2"));
            GameDAO.insert(new Game(987, "Game3"));
        }, "there is actually no way for this to fail");

    }

}
