package passoffTests;

import chess.*;

/**
 * Used for testing your code
 * Add in code using your classes for each method for each FIXME
 */
public class TestFactory {

    //Chess Functions
    //------------------------------------------------------------------------------------------------------------------
    public static ChessBoard getNewBoard(){
        // FIXME
        ChessBoards board = new ChessBoards();
        return board;
		//return null;
    }

    public static ChessGame getNewGame(){
        ChessGames game = new ChessGames(); /// I ADDED BOARD, THAT WASN'T A PARAMETER B4
        // FIXME
        return game;
    }

    public static ChessPiece getNewPiece(ChessGame.TeamColor pieceColor, ChessPiece.PieceType type){
        // FIXME
        return switch (type) {
            case KING -> new King(pieceColor, ChessPiece.PieceType.KING);
            case QUEEN -> new Queen(pieceColor, ChessPiece.PieceType.QUEEN);
            case PAWN -> new Pawn(pieceColor, ChessPiece.PieceType.PAWN);
            case ROOK -> new Rook(pieceColor, ChessPiece.PieceType.ROOK);
            case BISHOP -> new Bishop(pieceColor, ChessPiece.PieceType.BISHOP);
            case KNIGHT -> new Knight(pieceColor, ChessPiece.PieceType.KNIGHT);
        };
    }

    public static ChessPosition getNewPosition(Integer row, Integer col){
        ChessPositions position = new ChessPositions(row, col);
        // FIXME
        return position;
    }

    public static ChessMove getNewMove(ChessPosition startPosition, ChessPosition endPosition, ChessPiece.PieceType promotionPiece){
        // FIXME
        ChessMoves move = new ChessMoves(startPosition, endPosition, promotionPiece);
        return move;
    }
    //------------------------------------------------------------------------------------------------------------------


    //server.Server API's
    //------------------------------------------------------------------------------------------------------------------
    public static String getServerPort(){
        return "8080";
    }
    //------------------------------------------------------------------------------------------------------------------


    //Websocket Tests
    //------------------------------------------------------------------------------------------------------------------
    public static Long getMessageTime(){
        /*
        Changing this will change how long tests will wait for the server to send messages.
        3000 Milliseconds (3 seconds) will be enough for most computers. Feel free to change as you see fit,
        just know increasing it can make tests take longer to run.
        (On the flip side, if you've got a good computer feel free to decrease it)
         */
        return 6000L;
    }
    //------------------------------------------------------------------------------------------------------------------
}
