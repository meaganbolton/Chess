package passoffTests.serverTests;
import models.Game;
import org.junit.jupiter.api.*;
import request.CreateGameRequest;
import request.JoinGameRequest;
import request.LoginRequest;
import request.RegisterRequest;
import result.BaseResult;
import result.CreateGameResult;
import result.ListGameResult;
import result.LoginResult;
import services.*;

import java.util.ArrayList;
import java.util.Collections;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestiTests {
    public LoginResult registerAUser(){
        RegisterService service = new RegisterService();
        RegisterRequest req = new RegisterRequest("Bab", "pass", "Email");
        return service.register(req);
    }
    public LoginResult loggingIn(){
        registerAUser();
        LoginService service = new LoginService();
        LoginRequest req = new LoginRequest("Bab", "pass");
        return service.login(req);
    }
    public CreateGameResult creatingGame(LoginResult inResult){
        CreateGameService service = new CreateGameService();
        CreateGameRequest req = new CreateGameRequest("Game1");
        return  service.createGame(req, inResult.getAuthToken());
    }
    @BeforeEach
    public void clearing(){
        new ClearService().clear();
    }
    @Test
    @Order(1)
    @DisplayName("Positive User Register")
    public void successRegister() {
        LoginResult res =  registerAUser();

        Assertions.assertNull(res.getMessage(), "Register failed unexpectedly");
        Assertions.assertEquals("Bab", res.getUsername(), "Usernames were not found equal");
    }
    @Test
    @Order(2)
    @DisplayName("Negative User Register1")
    public void failRegister1() {
        registerAUser();
        LoginResult res =  registerAUser();

        Assertions.assertEquals("Error: already taken", res.getMessage(), "The message doesn't return \"already taken\"");
        // testing bad request
        RegisterService service = new RegisterService();
        RegisterRequest req = new RegisterRequest("Bab", null, "Email");
        LoginResult ress = service.register(req);

        Assertions.assertEquals("Error: bad request", ress.getMessage(), "The message doesn't return \"bad request\"");
    }
    @Test
    @Order(3)
    @DisplayName("Positive User Login")
    public void successLogin() {
        LoginResult res = loggingIn();

        Assertions.assertNull(res.getMessage(), "Register failed unexpectedly");
        Assertions.assertEquals("Bab", res.getUsername(), "Usernames were not found equal");
    }
    @Test
    @Order(4)
    @DisplayName("Negative User Login")
    public void failLogin() {
        registerAUser();
        LoginService service = new LoginService();
        LoginRequest req = new LoginRequest("Babby", "pass");
        LoginResult res = service.login(req);

        Assertions.assertEquals("Error: unauthorized", res.getMessage(), "The message doesn't return \"unauthorized\"");
        LoginRequest req2 = new LoginRequest("Bab", "passy");
        LoginResult res2 = service.login(req2);

        Assertions.assertEquals("Error: unauthorized", res2.getMessage(), "The message doesn't return \"unauthorized\"");
    }
    @Test
    @Order(5)
    @DisplayName("Positive User Logout")
    public void successLogout() {
        LoginResult inResult = loggingIn();

        LogoutService serviceOut = new LogoutService();
        BaseResult res = serviceOut.logout(inResult.getAuthToken());

        Assertions.assertNull(res.getMessage(), "Success logout");
    }
    @Test
    @Order(6)
    @DisplayName("Negative User Logout")
    public void failLogout() {
        loggingIn();
        LogoutService serviceOut = new LogoutService();
        BaseResult res = serviceOut.logout("This isn't a real authtoken");

        Assertions.assertEquals("Error: unauthorized", res.getMessage(), "Usernames were not found equal");
    }
    @Test
    @Order(7)
    @DisplayName("Positive CreateGame")
    public void successCreateGames() {
        LoginResult inResult = loggingIn();
        CreateGameResult res = creatingGame(inResult);
        Assertions.assertNotNull(res.getGameID());
    }
    @Test
    @Order(8)
    @DisplayName("Negative CreateGame1")
    public void failureCreateGames1() {
        // testing unauthorized error
        loggingIn();
        CreateGameService service = new CreateGameService();
        CreateGameRequest req = new CreateGameRequest("Game1");

        CreateGameResult res = service.createGame(req, "this isn't a token");

        Assertions.assertEquals("Error: unauthorized", res.getMessage(), "Usernames were not found equal");
        // testing bad request error
        clearing();
        loggingIn();
        CreateGameService servicee = new CreateGameService();
        CreateGameRequest reqq = new CreateGameRequest(null);

        CreateGameResult ress = servicee.createGame(reqq, "this isn't a token");

        Assertions.assertEquals("Error: bad request", ress.getMessage(), "Usernames were not found equal");
    }

    @Test
    @Order(9)
    @DisplayName("Positive JoinGame")
    public void successJoinGame() {
        LoginResult inResult = loggingIn();
        CreateGameResult gameRes = creatingGame(inResult);
        JoinGameRequest req = new JoinGameRequest(gameRes.getGameID(), "WHITE");
        JoinGameService service = new JoinGameService();
        BaseResult res = service.joinGame(req, inResult.getAuthToken());

        Assertions.assertNull(res.getMessage(), "There's a message when there shouldn't be");
    }
    @Test
    @Order(10)
    @DisplayName("Negative JoinGame1")
    public void failJoinGame1() {
        // testing bad request error
        LoginResult inResult = loggingIn();
        creatingGame(inResult);
        JoinGameRequest req = new JoinGameRequest(789, "WHITE");
        JoinGameService service = new JoinGameService();
        BaseResult res = service.joinGame(req, inResult.getAuthToken());

        Assertions.assertEquals("Error: bad request", res.getMessage(), "message doesn't return bad request");
        // testing unauthorizedcd error
        clearing();
        LoginResult inResult2 = loggingIn();
        CreateGameResult gameRes2 = creatingGame(inResult2);
        JoinGameRequest req2 = new JoinGameRequest(gameRes2.getGameID(), "WHITE");
        JoinGameService service2 = new JoinGameService();
        BaseResult res2 = service2.joinGame(req2, "wrong authtoken");

        Assertions.assertEquals("Error: unauthorized", res2.getMessage(), "message doesn't return unathorized");
        // testing already taken error
        clearing();
        LoginResult inResult3 = loggingIn();
        CreateGameResult gameRes3 = creatingGame(inResult3);
        JoinGameRequest req3 = new JoinGameRequest(gameRes3.getGameID(), "WHITE");
        JoinGameService service3 = new JoinGameService();
        service3.joinGame(req3, inResult3.getAuthToken());
        JoinGameRequest req4 = new JoinGameRequest(gameRes3.getGameID(), "WHITE");
        JoinGameService service4 = new JoinGameService();
        BaseResult res3 = service4.joinGame(req4, inResult3.getAuthToken());

        Assertions.assertEquals("Error: already taken", res3.getMessage(), "message doesn't return already taken");

    }

    @Test
    @Order(11)
    @DisplayName("Positive ListGame")
    public void successListGame() {
        LoginResult inResult = loggingIn();
        CreateGameResult gameRes1 = creatingGame(inResult);
        //// creating a new user
        RegisterService service = new RegisterService();
        RegisterRequest req = new RegisterRequest("Meagan", "456123Meagan", "meaganisdaboom@gmail.com");
        LoginResult res = service.register(req);
        /// creating a game for them
        CreateGameService servicee = new CreateGameService();
        CreateGameRequest reqq = new CreateGameRequest("Game2");
        CreateGameResult game2res = servicee.createGame(reqq, res.getAuthToken());
        /// using join game to put their info in the game to make sure everything is listed out
        JoinGameRequest reqJoin1 = new JoinGameRequest(gameRes1.getGameID(), "WHITE");
        JoinGameRequest reqJoin2 = new JoinGameRequest(gameRes1.getGameID(), "BLACK");

        JoinGameService serviceJoin = new JoinGameService();
        serviceJoin.joinGame(reqJoin1, inResult.getAuthToken());
        serviceJoin.joinGame(reqJoin2, res.getAuthToken());
        serviceJoin.joinGame(reqJoin2, res.getAuthToken());

        ListGameService serviceList = new ListGameService();
        ListGameResult listgame = serviceList.list(res.getAuthToken());

        ArrayList<Game> list = listgame.getGames();
        Collections.sort(list);
        if(list.get(0).getGameID() == gameRes1.getGameID()) {
            Assertions.assertEquals(gameRes1.getGameID(), list.get(0).getGameID(), "Incorrect ID shown");
            Assertions.assertEquals("Bab", list.get(0).getWhiteUsername(), "Incorrect white username shown");
            Assertions.assertEquals("Meagan", list.get(0).getBlackUsername(), "Incorrect black username shown");
            Assertions.assertEquals("Game1", list.get(0).getGameName(), "Incorrect game name");
            Assertions.assertEquals("Bab", list.get(0).getWhiteUsername(), "Incorrect username shown");
            Assertions.assertEquals(game2res.getGameID(), list.get(1).getGameID(), "Incorrect ID for 2nd game");
            Assertions.assertNull(list.get(1).getWhiteUsername(), "Not null white username for 2nd game");
            Assertions.assertNull(list.get(1).getBlackUsername(), "Not null black username for 2nd game");
            Assertions.assertEquals("Game2", list.get(1).getGameName(), "Incorrect game name for 2nd game");
        }
        else {
            Assertions.assertEquals(gameRes1.getGameID(), list.get(1).getGameID(), "Incorrect ID shown");
            Assertions.assertEquals(gameRes1.getGameID(), list.get(1).getGameID(), "Incorrect ID shown");
            Assertions.assertEquals("Bab", list.get(1).getWhiteUsername(), "Incorrect white username shown");
            Assertions.assertEquals("Meagan", list.get(1).getBlackUsername(), "Incorrect black username shown");
            Assertions.assertEquals("Game1", list.get(1).getGameName(), "Incorrect game name");
            Assertions.assertEquals("Bab", list.get(1).getWhiteUsername(), "Incorrect username shown");
            Assertions.assertEquals(game2res.getGameID(), list.get(0).getGameID(), "Incorrect ID for 2nd game");
            Assertions.assertNull(list.get(0).getWhiteUsername(), "Not null white username for 2nd game");
            Assertions.assertNull(list.get(0).getBlackUsername(), "Not null black username for 2nd game");
            Assertions.assertEquals("Game2", list.get(0).getGameName(), "Incorrect game name for 2nd game");
        }
    }
    @Test
    @Order(12)
    @DisplayName("Negative ListGame")
    public void failListGame() {
        LoginResult inResult = loggingIn();
        CreateGameResult gameRes1 = creatingGame(inResult);
        //// creating a new user
        RegisterService service = new RegisterService();
        RegisterRequest req = new RegisterRequest("Meagan", "456123Meagan", "meaganisdaboom@gmail.com");
        LoginResult res = service.register(req);
        /// creating a game for them
        CreateGameService servicee = new CreateGameService();
        CreateGameRequest reqq = new CreateGameRequest("Game2");
        servicee.createGame(reqq, res.getAuthToken());
        /// using join game to put their info in the game to make sure everything is listed out
        JoinGameRequest reqJoin1 = new JoinGameRequest(gameRes1.getGameID(), "WHITE");
        JoinGameRequest reqJoin2 = new JoinGameRequest(gameRes1.getGameID(), "BLACK");

        JoinGameService serviceJoin = new JoinGameService();
        serviceJoin.joinGame(reqJoin1, inResult.getAuthToken());
        serviceJoin.joinGame(reqJoin2, res.getAuthToken());

        ListGameService serviceList = new ListGameService();
        ListGameResult listgame = serviceList.list("Not a real authtoken");


        Assertions.assertEquals("Error: unauthorized", listgame.getMessage(), "Doesn't throw error for unauthorized");
    }
    @Test
    @Order(13)
    @DisplayName("Positive Clear")
    public void successClear() {
        ClearService clearTest = new ClearService();
        BaseResult clearRes = clearTest.clear();
        Assertions.assertNull(clearRes.getMessage(), "clear isn't clearing");
    }
}


